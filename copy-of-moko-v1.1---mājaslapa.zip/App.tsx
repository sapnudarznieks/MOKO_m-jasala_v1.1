import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Niches } from './components/Niches';
import { WebFeatures } from './components/WebFeatures';
import { WhyMoko } from './components/WhyMoko';
import { Automations } from './components/Automations';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { Chatbot } from './components/Chatbot';
import { LanguageProvider } from './contexts/LanguageContext';

function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen font-sans bg-white text-moko-black selection:bg-moko-yellow selection:text-black">
        <Navbar />
        <main>
          <Hero />
          <Niches />
          <WebFeatures />
          <WhyMoko />
          <Automations />
          <Contact />
        </main>
        <Footer />
        <Chatbot />
      </div>
    </LanguageProvider>
  );
}

export default App;