import { LucideIcon } from 'lucide-react';

export type Language = 'en' | 'lv';

export interface Niche {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  benefits: string[];
  automationExample: string;
  imageUrl: string;
}

export interface SecondaryNiche {
  id: string;
  title: string;
  description: string; // The main hook
  problem: string; // The pain point
  solution: string; // How MOKO solves it
  benefits: string[];
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
}

export enum ButtonVariant {
  PRIMARY = 'PRIMARY',
  SECONDARY = 'SECONDARY',
  OUTLINE = 'OUTLINE',
  GHOST = 'GHOST'
}