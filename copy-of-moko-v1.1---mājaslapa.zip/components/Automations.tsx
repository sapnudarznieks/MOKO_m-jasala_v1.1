import React from 'react';
import { MessageCircle, PhoneMissed, CalendarCheck, Star } from 'lucide-react';
import { Button } from './Button';
import { ButtonVariant } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Automations: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).automations;

  const getIcon = (type: string) => {
    switch(type) {
      case 'phone': return <PhoneMissed className="w-5 h-5 text-red-500" />;
      case 'calendar': return <CalendarCheck className="w-5 h-5 text-blue-500" />;
      case 'star': return <Star className="w-5 h-5 text-moko-yellow" />;
      default: return <Star className="w-5 h-5" />;
    }
  };

  return (
    <section id="automations" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          
          <div className="lg:w-1/2">
            <h2 className="text-3xl md:text-4xl font-bold text-moko-black mb-6">
              {content.titlePre} <br/>
              <span className="text-moko-yellow">{content.titleHighlight}</span>
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              {content.description}
            </p>

            <div className="space-y-6">
              {content.items.map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white border border-gray-200 flex items-center justify-center shadow-sm">
                     {getIcon(item.iconType)}
                  </div>
                  <div>
                     <h4 className="text-lg font-bold text-gray-900">{item.title}</h4>
                     <p className="text-gray-600">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10">
              <Button variant={ButtonVariant.PRIMARY}>
                {content.cta}
              </Button>
            </div>
          </div>

          <div className="lg:w-1/2 w-full">
            {/* Chat Interface Mockup */}
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden max-w-md mx-auto">
              <div className="bg-moko-black p-4 flex items-center gap-3">
                <div className="w-8 h-8 bg-moko-yellow rounded-full flex items-center justify-center font-bold text-xs">M</div>
                <div className="text-white font-medium">{content.chat.title}</div>
              </div>
              <div className="p-6 space-y-4 bg-gray-50 h-[400px] overflow-y-auto">
                
                <div className="flex justify-end">
                  <div className="bg-blue-600 text-white px-4 py-2 rounded-2xl rounded-tr-none max-w-[80%] text-sm">
                    {content.chat.user1}
                  </div>
                </div>
                <div className="text-xs text-gray-400 text-right">Customer • 10:42 AM</div>

                <div className="flex justify-start">
                  <div className="bg-white border border-gray-200 text-gray-800 px-4 py-2 rounded-2xl rounded-tl-none max-w-[80%] text-sm shadow-sm">
                    {content.chat.bot1}
                  </div>
                </div>
                <div className="text-xs text-gray-400 flex items-center gap-1">
                   <MessageCircle className="w-3 h-3" /> Automated • 10:42 AM
                </div>

                <div className="flex justify-end">
                  <div className="bg-blue-600 text-white px-4 py-2 rounded-2xl rounded-tr-none max-w-[80%] text-sm">
                    {content.chat.user2}
                  </div>
                </div>

                <div className="flex justify-start">
                  <div className="bg-white border border-gray-200 text-gray-800 px-4 py-2 rounded-2xl rounded-tl-none max-w-[80%] text-sm shadow-sm">
                    {content.chat.bot2}
                  </div>
                </div>
                 <div className="text-xs text-gray-400 flex items-center gap-1">
                   <MessageCircle className="w-3 h-3" /> Automated • 10:43 AM
                </div>

              </div>
              <div className="p-4 border-t border-gray-100 bg-white text-center text-xs text-gray-400">
                {content.chat.powered}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};