import React, { useState } from 'react';
import { Button } from './Button';
import { ButtonVariant, SecondaryNiche } from '../types';
import { ArrowRight, Cog, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Niches: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).niches;
  const [selectedSecondary, setSelectedSecondary] = useState<SecondaryNiche | null>(null);

  const handleBookClick = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    setSelectedSecondary(null);
  };

  const getIconAnimation = (id: string) => {
    switch (id) {
      case 'car-wash': return 'group-hover:animate-drip';
      case 'auto-repair': return 'group-hover:animate-wrench';
      case 'detailing': return 'group-hover:animate-pulse'; // Zap
      case 'rental': return 'group-hover:animate-wiggle'; // Calendar
      case 'dealership': return 'group-hover:animate-drive'; // Car
      default: return 'group-hover:animate-pulse';
    }
  };

  return (
    <section id="niches" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-moko-black mb-4">{content.title}</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        {/* Primary Niches */}
        <div className="space-y-20">
          {content.items.map((niche, index) => (
            <div 
              key={niche.id} 
              id={niche.id}
              className={`flex flex-col ${index % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-12 items-center scroll-mt-32`}
            >
              <div className="flex-1 w-full">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-video group bg-gray-100">
                  <div className="absolute inset-0 bg-moko-black/10 z-20 group-hover:bg-transparent transition-colors duration-300"></div>
                  <img 
                    src={niche.imageUrl} 
                    alt={niche.title} 
                    className="absolute inset-0 w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-in-out z-10"
                  />
                  <div className="absolute bottom-4 left-4 z-30 bg-white/90 backdrop-blur px-4 py-2 rounded-lg shadow-sm">
                    <div className="flex items-center text-sm font-bold text-moko-black">
                      <niche.icon className={`w-4 h-4 mr-2 text-moko-yellow ${getIconAnimation(niche.id)}`} />
                      {niche.title}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 space-y-6">
                <div className="inline-block p-3 bg-moko-yellow/10 rounded-lg group cursor-default">
                  <niche.icon className={`w-8 h-8 text-moko-yellow ${getIconAnimation(niche.id)}`} />
                </div>
                <h3 className="text-3xl font-bold text-moko-black">{niche.title}</h3>
                <p className="text-lg text-gray-600 leading-relaxed">{niche.description}</p>
                
                <div className="bg-gray-50 rounded-xl p-6 border border-gray-100">
                  <h4 className="font-semibold text-moko-black mb-3 flex items-center">
                    <Cog className="w-4 h-4 mr-2 animate-spin-slow" />
                    {content.keyAutomations}
                  </h4>
                  <ul className="space-y-2 mb-4">
                    {niche.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start text-gray-600 text-sm">
                        <span className="mr-2 text-moko-yellow">•</span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                  <div className="text-sm bg-white p-3 rounded border border-gray-200 text-gray-500 italic">
                    "{niche.automationExample}"
                  </div>
                </div>

                <Button 
                  variant={ButtonVariant.OUTLINE} 
                  className="group"
                  onClick={handleBookClick}
                >
                  {content.bookBtn}
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Secondary Niches Grid */}
        <div className="mt-24 pt-16 border-t border-gray-100">
          <div className="text-center mb-10">
             <h3 className="text-2xl font-bold text-moko-black mb-2">{content.secondaryTitle}</h3>
             <p className="text-gray-500 text-sm">{content.secondarySubtitle}</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {(content.secondary as SecondaryNiche[]).map((niche) => (
              <div 
                key={niche.id} 
                onClick={() => setSelectedSecondary(niche)}
                className="bg-gray-50 hover:bg-moko-yellow/10 transition-all p-6 rounded-xl text-center cursor-pointer group border border-transparent hover:border-moko-yellow/20 hover:-translate-y-1"
              >
                <p className="font-medium text-gray-800 group-hover:text-black transition-colors">{niche.title}</p>
                <div className="mt-2 text-xs text-gray-400 group-hover:text-gray-600 transition-colors">
                   {language === 'lv' ? 'Uzzināt vairāk' : 'Learn more'} →
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal for Secondary Niches */}
      {selectedSecondary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div 
             className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200"
             onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-moko-black p-6 text-white flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-bold">{selectedSecondary.title}</h3>
                <p className="text-gray-400 mt-1 text-sm">{selectedSecondary.description}</p>
              </div>
              <button 
                onClick={() => setSelectedSecondary(null)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              
              {/* Problem / Solution */}
              <div className="space-y-4">
                <div className="flex gap-3">
                   <div className="mt-1">
                      <AlertCircle className="w-5 h-5 text-red-500" />
                   </div>
                   <div>
                      <h4 className="font-bold text-gray-900 text-sm uppercase tracking-wide mb-1">
                        {language === 'lv' ? 'Problēma' : 'The Problem'}
                      </h4>
                      <p className="text-gray-600 text-sm">{selectedSecondary.problem}</p>
                   </div>
                </div>
                 <div className="flex gap-3">
                   <div className="mt-1">
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                   </div>
                   <div>
                      <h4 className="font-bold text-gray-900 text-sm uppercase tracking-wide mb-1">
                        {language === 'lv' ? 'MOKO Risinājums' : 'MOKO Solution'}
                      </h4>
                      <p className="text-gray-600 text-sm">{selectedSecondary.solution}</p>
                   </div>
                </div>
              </div>

              {/* Benefits List */}
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                <h4 className="font-semibold text-gray-900 mb-3 text-sm">
                  {language === 'lv' ? 'Ieguvumi' : 'Key Benefits'}
                </h4>
                <ul className="space-y-2">
                  {selectedSecondary.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-center text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-moko-yellow mr-2"></div>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>

              <Button variant={ButtonVariant.PRIMARY} className="w-full" onClick={handleBookClick}>
                {content.bookBtn}
              </Button>
            </div>
          </div>
          
          {/* Click outside to close */}
          <div className="absolute inset-0 -z-10" onClick={() => setSelectedSecondary(null)}></div>
        </div>
      )}
    </section>
  );
};