import React from 'react';
import { ShieldCheck, Trophy, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const WhyMoko: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).why;

  return (
    <section id="why-moko" className="py-20 bg-moko-black text-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gray-900/50 skew-x-12 translate-x-1/4"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">{content.title}</h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {content.features.map((feature) => (
            <div key={feature.id} className="bg-gray-900 p-8 rounded-2xl border border-gray-800 hover:border-moko-yellow/50 transition-all duration-300 hover:-translate-y-1 group">
              <div className="bg-gray-800 rounded-lg p-3 w-fit mb-6 group-hover:bg-moko-yellow group-hover:text-black transition-colors">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-center border-t border-gray-800 pt-12">
            <div className="flex flex-col items-center">
                <ShieldCheck className="w-10 h-10 text-moko-yellow mb-4" />
                <h4 className="text-xl font-bold">{content.trust.secure.title}</h4>
                <p className="text-gray-500 mt-2">{content.trust.secure.desc}</p>
            </div>
            <div className="flex flex-col items-center">
                <Trophy className="w-10 h-10 text-moko-yellow mb-4" />
                <h4 className="text-xl font-bold">{content.trust.experts.title}</h4>
                <p className="text-gray-500 mt-2">{content.trust.experts.desc}</p>
            </div>
            <div className="flex flex-col items-center">
                <Users className="w-10 h-10 text-moko-yellow mb-4" />
                <h4 className="text-xl font-bold">{content.trust.support.title}</h4>
                <p className="text-gray-500 mt-2">{content.trust.support.desc}</p>
            </div>
        </div>
      </div>
    </section>
  );
};