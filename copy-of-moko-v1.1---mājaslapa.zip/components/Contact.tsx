import React from 'react';
import { Button } from './Button';
import { ButtonVariant } from '../types';
import { Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Contact: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).contact;

  return (
    <section id="contact" className="py-20 bg-moko-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          
          <div>
            <h2 className="text-4xl font-bold mb-6">{content.title}</h2>
            <p className="text-gray-400 mb-10 text-lg">
              {content.description}
            </p>

            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-moko-yellow">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm text-gray-500">{content.labels.email}</div>
                  <div className="font-medium">info@moko.lv</div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-moko-yellow shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm text-gray-500 mb-1">{content.labels.call}</div>
                  <div className="font-medium flex flex-col gap-1">
                    <a href="tel:+37129563442" className="hover:text-moko-yellow transition-colors">+371 2956 3442</a>
                    <a href="tel:+37129110002" className="hover:text-moko-yellow transition-colors">+371 2911 0002</a>
                  </div>
                </div>
              </div>

               <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-moko-yellow">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm text-gray-500">{content.labels.office}</div>
                  <div className="font-medium">Rīga, Latvia</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 text-moko-black shadow-2xl">
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">{content.labels.name}</label>
                <input 
                  type="text" 
                  id="name" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moko-yellow focus:border-transparent outline-none transition-all"
                  placeholder="Jānis Bērziņš"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">{content.labels.workEmail}</label>
                <input 
                  type="email" 
                  id="email" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moko-yellow focus:border-transparent outline-none transition-all"
                  placeholder="janis@example.com"
                />
              </div>

              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">{content.labels.company}</label>
                <input 
                  type="text" 
                  id="company" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moko-yellow focus:border-transparent outline-none transition-all"
                  placeholder="Your Auto Shop"
                />
              </div>

              <div>
                <label htmlFor="niche" className="block text-sm font-medium text-gray-700 mb-1">{content.labels.businessType}</label>
                <select 
                  id="niche" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moko-yellow focus:border-transparent outline-none transition-all bg-white"
                >
                  {content.businessTypes.map((type, idx) => (
                    <option key={idx}>{type}</option>
                  ))}
                </select>
              </div>

              <Button variant={ButtonVariant.PRIMARY} className="w-full py-4 text-lg font-bold mt-4">
                {content.labels.bookBtn}
              </Button>
              
              <p className="text-xs text-center text-gray-400 mt-4">
                {content.labels.disclaimer}
              </p>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};