import React from 'react';
import { ButtonVariant } from '../types';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  className?: string;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  variant = ButtonVariant.PRIMARY, 
  className = '', 
  children, 
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center px-8 py-3 border text-base font-medium rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-moko-yellow disabled:opacity-50 disabled:cursor-not-allowed";
  
  let variantStyles = "";

  switch (variant) {
    case ButtonVariant.PRIMARY:
      variantStyles = "border-transparent text-black bg-moko-yellow hover:bg-yellow-400 shadow-md";
      break;
    case ButtonVariant.SECONDARY:
      variantStyles = "border-transparent text-white bg-moko-black hover:bg-gray-900 shadow-md";
      break;
    case ButtonVariant.OUTLINE:
      variantStyles = "border-moko-black text-moko-black bg-transparent hover:bg-gray-50";
      break;
    case ButtonVariant.GHOST:
      variantStyles = "border-transparent text-moko-black hover:bg-gray-100 px-4";
      break;
  }

  return (
    <button 
      className={`${baseStyles} ${variantStyles} ${className}`} 
      {...props}
    >
      {children}
    </button>
  );
};