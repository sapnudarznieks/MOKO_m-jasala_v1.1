import React from 'react';
import { Quote } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Testimonials: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).testimonials;

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-moko-black mb-16">
          {content.title}
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          {content.items.map((t) => (
            <div key={t.id} className="bg-gray-50 p-8 rounded-2xl relative">
              <Quote className="absolute top-6 left-6 w-10 h-10 text-moko-yellow/20" />
              <p className="text-gray-600 mb-6 relative z-10 italic">"{t.content}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-moko-black text-moko-yellow flex items-center justify-center font-bold">
                    {t.name.charAt(0)}
                </div>
                <div>
                    <div className="font-bold text-moko-black">{t.name}</div>
                    <div className="text-xs text-gray-500">{t.role}, {t.company}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};