import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, Loader2 } from 'lucide-react';
import { GoogleGenAI, Chat } from "@google/genai";
import { useLanguage } from '../contexts/LanguageContext';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const Chatbot: React.FC = () => {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'model', 
      text: language === 'lv' 
        ? 'Sveiki! Esmu MOKO AI asistents. Jautājiet man, kā mēs varam automatizēt jūsu auto biznesu.' 
        : 'Hello! I am MOKO AI. Ask me how we can automate your automotive business today.' 
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatSessionRef = useRef<Chat | null>(null);

  // Update initial message when language changes, if it's the only message
  useEffect(() => {
    if (messages.length === 1 && messages[0].role === 'model') {
       setMessages([{ 
         role: 'model', 
         text: language === 'lv' 
           ? 'Sveiki! Esmu MOKO AI asistents. Jautājiet man, kā mēs varam automatizēt jūsu auto biznesu.' 
           : 'Hello! I am MOKO AI. Ask me how we can automate your automotive business today.' 
       }]);
    }
  }, [language]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  // Initialize Chat Session with Language Context
  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    chatSessionRef.current = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        temperature: 0.7,
        systemInstruction: `
          You are MOKO AI, a specialized sales and product expert for MOKO, the official GoHighLevel (GHL) distributor in Latvia.
          
          CURRENT LANGUAGE CONTEXT:
          The user is viewing the website in: ${language === 'lv' ? 'LATVIAN' : 'ENGLISH'}.
          YOU MUST REPLY IN ${language === 'lv' ? 'LATVIAN' : 'ENGLISH'} unless the user specifically asks otherwise.
          
          YOUR PURPOSE:
          To explain the value, features, and capabilities of the MOKO system (built on GoHighLevel) to potential customers in the automotive industry.
          
          YOUR AUDIENCE:
          Owners and managers of:
          - Car Washes
          - Auto Repair Shops
          - Auto Detailing Centers
          - Car Rental Companies
          - Used Car Dealerships
          
          WHAT YOU KNOW (KNOWLEDGE BASE):
          - You are an expert on CRM, Marketing Automation, Booking Calendars, SMS Marketing, and Website funnels specifically for cars.
          - You know that MOKO helps reduce no-shows, automate appointment reminders, get more Google reviews, and reactivate old customers.
          - You know MOKO provides a Unified Inbox (FB, Insta, SMS, Email all in one place).
          
          CRITICAL RULE - NO TECHNICAL SUPPORT:
          You are NOT a technical support bot. You do not help with "how to fix" specific bugs, API keys, DNS settings, or broken workflows for existing users.
          If a user asks a technical troubleshooting question (e.g., "My calendar isn't syncing" or "How do I reset my password"), you must politely refuse and answer exactly:
          "I specialize in explaining MOKO's capabilities to new partners. For technical assistance or troubleshooting with your existing account, please visit our dedicated Support Section on the homepage."
          (Translate this refusal message to Latvian if the user asks in Latvian).
          
          TONE:
          Professional, confident, concise, and helpful. Use the "MOKO" brand voice: modern, premium, and value-driven.
          
          FORMATTING:
          Keep responses relatively short (under 3-4 sentences usually). Use bullet points if listing features.
        `,
      },
    });
  }, [language]); // Re-initialize if language changes to update system prompt context

  const handleSend = async () => {
    if (!input.trim() || isLoading || !chatSessionRef.current) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const result = await chatSessionRef.current.sendMessageStream({
        message: userMessage
      });

      let fullResponse = "";
      
      // Add a placeholder for the model response
      setMessages(prev => [...prev, { role: 'model', text: '' }]);

      for await (const chunk of result) {
        const chunkText = chunk.text || "";
        fullResponse += chunkText;
        
        // Update the last message with the accumulated text
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1] = { role: 'model', text: fullResponse };
          return newMessages;
        });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, { role: 'model', text: language === 'lv' ? 'Atvainojiet, radās savienojuma kļūda. Lūdzu, mēģiniet vēlreiz.' : "I'm having trouble connecting right now. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-moko-yellow ${
          isOpen ? 'bg-moko-black text-white rotate-90' : 'bg-moko-yellow text-moko-black'
        }`}
        aria-label="Toggle Chatbot"
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} fill="currentColor" />}
      </button>

      {/* Chat Window */}
      <div
        className={`fixed bottom-24 right-6 z-50 w-[90vw] md:w-[400px] h-[500px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden transition-all duration-300 origin-bottom-right ${
          isOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'
        }`}
      >
        {/* Header */}
        <div className="bg-moko-black p-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/10 p-2 rounded-full">
              <Bot className="text-moko-yellow w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">MOKO Assistant</h3>
              <p className="text-xs text-gray-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                Online
              </p>
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-moko-black text-white rounded-tr-none'
                    : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none shadow-sm'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-tl-none shadow-sm">
                <Loader2 className="w-4 h-4 animate-spin text-moko-yellow" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-gray-100 shrink-0">
          <div className="flex items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={language === 'lv' ? "Jautājiet par MOKO..." : "Ask about features..."}
              className="flex-1 resize-none max-h-32 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-moko-yellow focus:border-transparent outline-none custom-scrollbar"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-3 bg-moko-yellow text-moko-black rounded-xl hover:bg-yellow-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={18} />
            </button>
          </div>
          <div className="text-center mt-2">
             <p className="text-[10px] text-gray-400">
               {language === 'lv' ? 'AI var kļūdīties. Sazinieties ar atbalstu tehniskiem jautājumiem.' : 'AI can make mistakes. Contact support for technical help.'}
             </p>
          </div>
        </div>
      </div>
    </>
  );
};