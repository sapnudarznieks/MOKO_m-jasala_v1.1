import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const WebFeatures: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).webFeatures;

  const getIconAnimation = (idx: number) => {
    switch(idx) {
      case 0: return 'group-hover:animate-drag'; // Drag
      case 1: return 'group-hover:animate-wiggle'; // Smartphone
      case 2: return 'group-hover:animate-spin-slow'; // Globe
      case 3: return 'group-hover:animate-fly'; // Rocket
      default: return '';
    }
  };

  return (
    <section id="websites" className="py-20 bg-moko-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-moko-black mb-4">
            {content.title}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {content.features.map((feature, idx) => (
            <div 
              key={idx} 
              className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300 group"
            >
              <div className="w-12 h-12 bg-moko-yellow/10 rounded-lg flex items-center justify-center mb-6 text-moko-yellow">
                <feature.icon className={`w-6 h-6 ${getIconAnimation(idx)}`} />
              </div>
              <h3 className="text-xl font-bold text-moko-black mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-2xl overflow-hidden shadow-2xl border border-gray-200">
          <div className="bg-gray-100 px-4 py-3 border-b border-gray-200 flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-400"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
              <div className="w-3 h-3 rounded-full bg-green-400"></div>
            </div>
            <div className="bg-white px-3 py-1 rounded text-xs text-gray-400 flex-1 text-center mx-4">
              moko.lv/your-business
            </div>
          </div>
          <div className="aspect-[21/9] bg-gray-50 relative group overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
              alt="Website Builder Interface" 
              className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
            />
             <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-8">
                <p className="text-white text-lg font-medium">
                  {language === 'en' ? 'Drag & Drop Editor Example' : 'Vilkšanas un Nomešanas Redaktors'}
                </p>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};