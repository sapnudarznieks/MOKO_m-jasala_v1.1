import React, { useState, useEffect } from 'react';
import { Menu, X, Globe, ChevronDown } from 'lucide-react';
import { Button } from './Button';
import { ButtonVariant } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobileSolutionsOpen, setIsMobileSolutionsOpen] = useState(false);
  const { language, toggleLanguage } = useLanguage();
  
  const fullContent = getContent(language);
  const navContent = fullContent.nav;
  const nicheItems = fullContent.niches.items;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const otherLinks = [
    { name: navContent.websites, href: '#websites' },
    { name: navContent.why, href: '#why-moko' },
    { name: navContent.automations, href: '#automations' },
    { name: navContent.contact, href: '#contact' },
  ];

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id.replace('#', ''));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
      setIsMobileSolutionsOpen(false);
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center flex-shrink-0 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="flex flex-col items-center">
              <div className="text-4xl font-extrabold tracking-tighter leading-none">
                <span className="text-moko-black">M</span>
                <span className="text-moko-yellow">o</span>
                <span className="text-moko-black">k</span>
                <span className="text-moko-yellow">o</span>
              </div>
              <div className={`text-[0.5rem] font-bold tracking-[0.1em] mt-1 transition-opacity duration-300 ${isScrolled ? 'opacity-0 h-0' : 'opacity-100 text-moko-black'}`}>
                PĀRDOŠANA. MĀRKETINGS. AUTOMATIZĀCIJA.
              </div>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-6">
            
            {/* Solutions Dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 text-moko-black hover:text-moko-yellow font-medium transition-colors py-2">
                {navContent.solutions}
                <ChevronDown size={16} className="group-hover:rotate-180 transition-transform duration-200" />
              </button>
              
              <div className="absolute top-full left-0 w-72 bg-white shadow-xl rounded-xl border border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 translate-y-2 group-hover:translate-y-0">
                {/* Bridge gap */}
                <div className="absolute -top-4 left-0 w-full h-4 bg-transparent"></div>
                
                <div className="p-2">
                  {nicheItems.map((item) => (
                    <a 
                      key={item.id}
                      href={`#${item.id}`}
                      onClick={(e) => handleScroll(e, item.id)}
                      className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 hover:text-moko-yellow rounded-lg transition-colors cursor-pointer"
                    >
                      <div className="font-semibold">{item.title}</div>
                      <div className="text-xs text-gray-400 mt-0.5 truncate">{item.description.substring(0, 40)}...</div>
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {otherLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={(e) => handleScroll(e, link.href)}
                className="text-moko-black hover:text-moko-yellow font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
            
            <button 
              onClick={toggleLanguage}
              className="flex items-center gap-1 text-sm font-medium text-gray-600 hover:text-moko-black transition-colors px-2"
            >
              <Globe size={16} />
              {language.toUpperCase()}
            </button>

            <Button 
              variant={ButtonVariant.PRIMARY} 
              className="py-2 px-6 text-sm"
              onClick={(e) => handleScroll(e, 'contact')}
            >
              {navContent.book}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={toggleLanguage}
              className="flex items-center gap-1 text-sm font-medium text-gray-600"
            >
              {language.toUpperCase()}
            </button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-moko-black focus:outline-none"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white absolute w-full border-b border-gray-100 shadow-lg max-h-[80vh] overflow-y-auto">
          <div className="px-4 pt-2 pb-6 space-y-2">
            
            {/* Mobile Solutions Accordion */}
            <div>
              <button 
                onClick={() => setIsMobileSolutionsOpen(!isMobileSolutionsOpen)}
                className="flex w-full items-center justify-between px-3 py-2 text-base font-medium text-moko-black hover:bg-gray-50 rounded-md"
              >
                {navContent.solutions}
                <ChevronDown size={18} className={`transition-transform duration-200 ${isMobileSolutionsOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isMobileSolutionsOpen && (
                <div className="ml-4 mt-1 space-y-1 border-l-2 border-gray-100 pl-2">
                  {nicheItems.map((item) => (
                     <a
                      key={item.id}
                      href={`#${item.id}`}
                      className="block px-3 py-2 text-sm font-medium text-gray-600 hover:text-moko-yellow rounded-md"
                      onClick={(e) => handleScroll(e, item.id)}
                    >
                      {item.title}
                    </a>
                  ))}
                </div>
              )}
            </div>

            {otherLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-3 py-2 text-base font-medium text-moko-black hover:bg-gray-50 hover:text-moko-yellow rounded-md"
                onClick={(e) => handleScroll(e, link.href)}
              >
                {link.name}
              </a>
            ))}
            <div className="pt-4">
              <Button 
                variant={ButtonVariant.PRIMARY} 
                className="w-full justify-center"
                onClick={(e) => handleScroll(e, 'contact')}
              >
                {navContent.book}
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};