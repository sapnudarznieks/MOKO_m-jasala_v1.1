import React from 'react';
import { Facebook, Instagram, Linkedin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Footer: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).footer;

  return (
    <footer className="bg-black text-gray-400 py-12 border-t border-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          
          <div className="mb-6 md:mb-0">
             <div className="text-2xl font-extrabold tracking-tighter text-white">
                M<span className="text-moko-yellow">o</span>k<span className="text-moko-yellow">o</span>
              </div>
              <p className="text-sm mt-2">© {new Date().getFullYear()} GrowTech, SIA. {content.rights}</p>
          </div>

          <div className="flex space-x-6">
            <a href="#" className="hover:text-moko-yellow transition-colors"><Facebook className="w-5 h-5" /></a>
            <a href="#" className="hover:text-moko-yellow transition-colors"><Instagram className="w-5 h-5" /></a>
            <a href="#" className="hover:text-moko-yellow transition-colors"><Linkedin className="w-5 h-5" /></a>
          </div>

        </div>
      </div>
    </footer>
  );
};