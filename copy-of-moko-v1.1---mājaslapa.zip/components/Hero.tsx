import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from './Button';
import { ButtonVariant } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { getContent } from '../data';

export const Hero: React.FC = () => {
  const { language } = useLanguage();
  const content = getContent(language).hero;

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative pt-32 pb-16 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        {/* Automotive Background Image with Overlay */}
        <div className="absolute inset-0">
           <img 
            src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2560&auto=format&fit=crop" 
            alt="Modern Automotive Background" 
            className="w-full h-full object-cover opacity-[0.15] grayscale-[20%]"
           />
           <div className="absolute inset-0 bg-gradient-to-b from-white/80 via-white/90 to-white"></div>
        </div>

        {/* Animated Gradient Blobs */}
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-12 w-96 h-96 bg-moko-yellow/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
        <div className="absolute top-0 -right-4 w-96 h-96 bg-gray-200/50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-32 -left-20 w-96 h-96 bg-moko-yellow/10 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-moko-black tracking-tight mb-6 leading-[1.1]">
          {content.titlePre} <br className="hidden md:block" />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-moko-yellow to-yellow-500">
            {content.titleHighlight}
          </span>
        </h1>
        
        <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-600 mb-10 leading-relaxed">
          {content.description}
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
          <Button 
            variant={ButtonVariant.PRIMARY} 
            className="h-14 text-lg shadow-lg shadow-moko-yellow/20 hover:shadow-moko-yellow/30"
            onClick={() => scrollToSection('contact')}
          >
            {content.ctaStart} <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button 
            variant={ButtonVariant.OUTLINE} 
            className="h-14 text-lg bg-white/50 hover:bg-white backdrop-blur-sm"
            onClick={() => scrollToSection('niches')}
          >
            {content.ctaView}
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto text-sm font-medium text-gray-500 border-t border-gray-100 pt-10">
          {content.features.map((feature, idx) => (
            <div key={idx} className="flex items-center justify-center gap-2">
              <CheckCircle2 className="text-moko-yellow h-5 w-5" />
              <span>{feature}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};