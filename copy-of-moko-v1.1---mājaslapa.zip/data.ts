
import { 
  Wrench, 
  Car, 
  Droplets, 
  Calendar, 
  ShoppingBag, 
  Settings, 
  MessageSquare, 
  BarChart3, 
  Globe, 
  Zap,
  Smartphone,
  Rocket,
  Layout,
  Target
} from 'lucide-react';
import { Niche, SecondaryNiche, Language } from './types';

// Single Best Images for each Niche (Verified Working URLs)
const IMAGES = {
  carWash: 'https://images.unsplash.com/photo-1605152276897-4f618f831968?q=80&w=800&auto=format&fit=crop', // Black Nissan GT-R being washed
  autoRepair: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?q=80&w=800&auto=format&fit=crop', // Mechanic
  detailing: 'https://images.unsplash.com/photo-1601362840469-51e4d8d58785?q=80&w=800&auto=format&fit=crop', // Detailing process
  rental: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?q=80&w=800&auto=format&fit=crop', // Exterior car
  dealership: 'https://images.unsplash.com/photo-1606206791223-b4807f306c93?q=80&w=800&auto=format&fit=crop' // Standard dealership cars
};

export const CONTENT = {
  en: {
    nav: {
      solutions: 'Solutions',
      websites: 'Websites',
      why: 'Why MOKO',
      automations: 'Automations',
      contact: 'Contact',
      book: 'Book Consultation'
    },
    hero: {
      badge: 'Official GoHighLevel Partner in Latvia',
      titlePre: 'Automate Your',
      titleHighlight: 'Automotive Business',
      description: 'MOKO helps car washes, repair shops, and dealerships streamline operations, boost bookings, and retain customers with all-in-one automation.',
      ctaStart: 'Start With MOKO',
      ctaView: 'View Solutions',
      features: ['CRM Setup', 'Marketing Automation', 'Websites & Funnels', 'Booking Systems']
    },
    webFeatures: {
      title: 'High-Performance Websites',
      subtitle: 'More than just a pretty design. We build machines that convert visitors into customers.',
      features: [
        { title: 'Drag & Drop Builder', desc: 'Easily make changes yourself without coding.', icon: Layout },
        { title: 'Mobile Optimized', desc: 'Looks perfect on every device, guaranteed.', icon: Smartphone },
        { title: 'SEO Ready', desc: 'Built to rank high on Google for local searches.', icon: Globe },
        { title: 'Lightning Fast', desc: 'Optimized loading speeds for higher conversion.', icon: Rocket },
      ]
    },
    niches: {
      title: 'Built for the Automotive Industry',
      subtitle: 'Specialized automation workflows designed for your specific business model.',
      bookBtn: 'Book a Consultation',
      keyAutomations: 'Key Automations',
      secondaryTitle: 'We Also Serve',
      secondarySubtitle: 'Click on a niche to see how MOKO can help.',
      items: [
        {
          id: 'car-wash',
          title: 'Car Washes',
          description: 'Fill your wash bays automatically. Turn one-time visitors into monthly members with automated follow-ups.',
          icon: Droplets,
          benefits: [
            'Automated membership renewals',
            'Weather-triggered promotions',
            'Review generation on auto-pilot'
          ],
          automationExample: 'Send a 20% off coupon via SMS if it hasn\'t rained in 5 days.',
          imageUrl: IMAGES.carWash
        },
        {
          id: 'auto-repair',
          title: 'Auto Repair Shops',
          description: 'Reduce no-shows and keep bays full. Automate service reminders and status updates.',
          icon: Wrench,
          benefits: [
            'Automatic appointment reminders',
            'Status update SMS (Parts Ordered, Ready)',
            'Post-service review requests'
          ],
          automationExample: 'Automatically text client when their car is ready for pickup.',
          imageUrl: IMAGES.autoRepair
        },
        {
          id: 'detailing',
          title: 'Auto Detailing',
          description: 'Sell high-ticket ceramic coatings effortlessly. Manage deposits and bookings without phone tag.',
          icon: Zap,
          benefits: [
            'Deposit collection automation',
            'Before/After photo gallery follow-ups',
            'Annual maintenance reminders'
          ],
          automationExample: '6-month ceramic coating maintenance reminder sequence.',
          imageUrl: IMAGES.detailing
        },
        {
          id: 'rental',
          title: 'Car Rental',
          description: 'Streamline check-ins and manage fleet availability with integrated booking calendars.',
          icon: Calendar,
          benefits: [
            'Digital rental agreements',
            'Return reminders',
            'Fleet availability calendar'
          ],
          automationExample: 'Automated email with contract and pickup instructions upon booking.',
          imageUrl: IMAGES.rental
        },
        {
          id: 'dealership',
          title: 'Used Car Dealerships',
          description: 'Capture leads from Facebook & Classifieds instantly. Nurture them until they test drive.',
          icon: Car,
          benefits: [
            'Instant lead response (under 2 mins)',
            'Test drive scheduling',
            'Financing application automation'
          ],
          automationExample: 'Instant SMS response to "Is this available?" inquiries.',
          imageUrl: IMAGES.dealership
        }
      ],
      secondary: [
        {
          id: 'tires',
          title: 'Tire Services & Hotels',
          description: 'Manage seasonal chaos with automated booking.',
          problem: 'Phones ringing non-stop during peak season.',
          solution: 'Online booking system that manages bay capacity automatically.',
          benefits: ['Seasonal swap reminders', 'Tire hotel inventory tracking', 'Online booking links']
        },
        {
          id: 'glass',
          title: 'Auto Glass Replacement',
          description: 'Speed up insurance claims and installations.',
          problem: 'Communication delays with customers waiting for glass.',
          solution: 'Automated status updates when glass arrives.',
          benefits: ['Stock arrival alerts', 'Mobile service scheduling', 'Insurance claim document upload funnel']
        },
        {
          id: 'towing',
          title: 'Tow Truck / Vehicle Recovery',
          description: 'Dispatch and update customers instantly.',
          problem: 'Customers anxious about arrival times.',
          solution: 'Automated ETA text messages and driver tracking links.',
          benefits: ['GPS tracking links', 'Review requests after service', 'Partner repair shop referrals']
        },
        {
          id: 'parts',
          title: 'Car Parts & Accessories',
          description: 'Boost repeat sales and manage special orders.',
          problem: 'Lost sales from abandoned carts or forgotten inquiries.',
          solution: 'Abandoned cart recovery and stock notification automations.',
          benefits: ['Restock alerts', 'Abandoned cart SMS', 'Loyalty points system']
        },
        {
          id: 'school',
          title: 'Driving Schools',
          description: 'Fill classes and automate lesson scheduling.',
          problem: 'Coordinating instructor and student schedules manually.',
          solution: 'Self-service booking calendar for driving lessons.',
          benefits: ['Lesson reminders', 'License renewal marketing', 'Instructor availability mgmt']
        }
      ]
    },
    why: {
      title: 'Why Choose MOKO?',
      subtitle: 'We don\'t just give you software. We give you a fully built system ready to grow your business.',
      features: [
        { id: '1', title: 'All-in-One', description: 'Replace 5+ different tools. CRM, Email, SMS, Booking, and Website in one place.', icon: Settings },
        { id: '2', title: 'Automotive Focus', description: 'We only work with car businesses. We understand your terminology and customer lifecycle.', icon: Target },
        { id: '3', title: 'Unified Inbox', description: 'Facebook, Instagram, Email, and SMS messages all land in one simple chat window.', icon: MessageSquare },
        { id: '4', title: 'Data Driven', description: 'Real-time dashboards showing you exactly how much revenue your marketing is generating.', icon: BarChart3 },
      ],
      trust: {
        secure: { title: 'Secure & Reliable', desc: 'Enterprise-grade data protection.' },
        experts: { title: 'Automotive Focus', desc: 'Tailored tools for your industry.' },
        support: { title: 'Local Support', desc: 'We are based in Riga, Latvia.' }
      }
    },
    automations: {
      titlePre: 'Stop Chasing Leads.',
      titleHighlight: 'Start Closing Them.',
      description: 'Imagine a system that follows up with every lead within 2 minutes, 24/7. MOKO ensures no opportunity slips through the cracks.',
      cta: 'See All Automations',
      items: [
        { title: 'Missed Call Text-Back', desc: 'Automatically text customers who call when you\'re busy.', iconType: 'phone' },
        { title: 'Appointment Reminders', desc: 'Drastically reduce no-shows with automated confirmations.', iconType: 'calendar' },
        { title: 'Google Review Generator', desc: 'Turn happy customers into 5-star reviews automatically.', iconType: 'star' }
      ],
      chat: {
        title: 'Live Demo: Missed Call',
        user1: 'Hey, do you have availability for a wash today?',
        bot1: 'Hi! Thanks for contacting MOKO Car Wash. We are a bit busy, but you can book a slot directly here: moko.lv/book',
        user2: 'Great, just booked for 2 PM.',
        bot2: 'Perfect! We have confirmed your slot for 2 PM today. See you then!',
        powered: 'Powered by MOKO Automation'
      }
    },
    testimonials: {
       title: 'Trusted by Business Owners',
       items: []
    },
    contact: {
      title: 'Ready to Automate?',
      description: 'Book a free consultation call to see how MOKO can help your specific business save time and make more money.',
      labels: {
        email: 'Email Us',
        call: 'Call Us',
        office: 'Visit Us',
        name: 'Full Name',
        workEmail: 'Work Email',
        company: 'Company Name',
        businessType: 'Business Type',
        bookBtn: 'Book Consultation',
        disclaimer: 'By submitting this form, you agree to receive communications from MOKO.'
      },
      businessTypes: ['Car Wash', 'Auto Repair', 'Detailing', 'Car Rental', 'Dealership', 'Other']
    },
    footer: {
      rights: 'All rights reserved.'
    }
  },
  lv: {
    nav: {
      solutions: 'Risinājumi',
      websites: 'Mājaslapas',
      why: 'Kāpēc MOKO',
      automations: 'Automatizācija',
      contact: 'Kontakti',
      book: 'Pieteikt Konsultāciju'
    },
    hero: {
      badge: 'Oficiālais GoHighLevel Partneris Latvijā',
      titlePre: 'Automatizē Savu',
      titleHighlight: 'Auto Biznesu',
      description: 'MOKO palīdz auto mazgātavām, servisiem un dīleriem sakārtot procesus, palielināt rezervācijas un noturēt klientus ar "viss-vienā" automatizāciju.',
      ctaStart: 'Sākt ar MOKO',
      ctaView: 'Apskatīt Risinājumus',
      features: ['CRM Uzstādīšana', 'Mārketinga Automatizācija', 'Mājaslapas & Piltuves', 'Rezervāciju Sistēmas']
    },
    webFeatures: {
      title: 'Augstas Veiktspējas Mājaslapas',
      subtitle: 'Vairāk nekā tikai skaists dizains. Mēs būvējam sistēmas, kas pārvērš apmeklētājus par klientiem.',
      features: [
        { title: 'Drag & Drop Būvētājs', desc: 'Viegli veiciet izmaiņas paši bez programmēšanas.', icon: Layout },
        { title: 'Mobilā Optimizācija', desc: 'Izskatās perfekti jebkurā ierīcē, garantēts.', icon: Smartphone },
        { title: 'SEO Gatavība', desc: 'Veidots, lai ierindotos augstu Google vietējos meklējumos.', icon: Globe },
        { title: 'Zibenīgs Ātrums', desc: 'Optimizēts ielādes ātrums augstākai konversijai.', icon: Rocket },
      ]
    },
    niches: {
      title: 'Radīts Auto Industrijai',
      subtitle: 'Specializētas automatizācijas plūsmas, kas pielāgotas tieši jūsu biznesa modelim.',
      bookBtn: 'Pieteikt Konsultāciju',
      keyAutomations: 'Galvenās Automatizācijas',
      secondaryTitle: 'Mēs Apkalpojam Arī',
      secondarySubtitle: 'Noklikšķiniet uz nišas, lai redzētu, kā MOKO var palīdzēt.',
      items: [
        {
          id: 'car-wash',
          title: 'Auto Mazgātavas',
          description: 'Aizpildiet mazgāšanas boksu automātiski. Pārvērtiet vienreizējos apmeklētājus par ikmēneša abonentiem.',
          icon: Droplets,
          benefits: [
            'Automatizēta abonementu atjaunošana',
            'Laikapstākļu izraisītas akcijas',
            'Atsauksmju ģenerēšana autopilotā'
          ],
          automationExample: 'Nosūtīt 20% atlaidi SMS, ja nav lijis 5 dienas.',
          imageUrl: IMAGES.carWash
        },
        {
          id: 'auto-repair',
          title: 'Auto Servisi',
          description: 'Samaziniet neierašanos un turiet pacēlājus aizņemtus. Automatizējiet atgādinājumus un statusa atjauninājumus.',
          icon: Wrench,
          benefits: [
            'Automātiski pieraksta atgādinājumi',
            'Statusa SMS (Detaļas pasūtītas, Gatavs)',
            'Pēcpakalpojuma atsauksmju pieprasījumi'
          ],
          automationExample: 'Automātiski nosūtīt SMS klientam, kad auto ir gatavs saņemšanai.',
          imageUrl: IMAGES.autoRepair
        },
        {
          id: 'detailing',
          title: 'Auto Detailing',
          description: 'Pārdodiet dārgos keramikas pārklājumus bez piepūles. Pārvaldiet depozītus un rezervācijas bez zvanīšanās.',
          icon: Zap,
          benefits: [
            'Depozītu iekasēšanas automatizācija',
            'Pirms/Pēc foto galeriju "follow-up"',
            'Ikgadējie apkopes atgādinājumi'
          ],
          automationExample: '6 mēnešu keramikas pārklājuma apkopes atgādinājumu sērija.',
          imageUrl: IMAGES.detailing
        },
        {
          id: 'rental',
          title: 'Auto Noma',
          description: 'Vienkāršojiet auto izsniegšanu un pārvaldiet autoparka pieejamību ar integrētiem kalendāriem.',
          icon: Calendar,
          benefits: [
            'Digitālie nomas līgumi',
            'Atgriešanas atgādinājumi',
            'Autoparka pieejamības kalendārs'
          ],
          automationExample: 'Automātisks e-pasts ar līgumu un saņemšanas instrukcijām pēc rezervācijas.',
          imageUrl: IMAGES.rental
        },
        {
          id: 'dealership',
          title: 'Auto Tirdzniecība',
          description: 'Tveriet "leadus" no Facebook un sludinājumiem uzreiz. Sildiet tos līdz testa braucienam.',
          icon: Car,
          benefits: [
            'Tūlītēja atbilde (zem 2 min)',
            'Testa braucienu plānošana',
            'Līzinga pieteikumu automatizācija'
          ],
          automationExample: 'Tūlītēja SMS atbilde uz "Vai šis ir pieejams?" jautājumiem.',
          imageUrl: IMAGES.dealership
        }
      ],
      secondary: [
        {
          id: 'tires',
          title: 'Riepu Servisi & Viesnīcas',
          description: 'Pārvaldiet sezonālo haosu ar automatizētu rezervāciju.',
          problem: 'Telefoni zvana nepārtraukti sezonas laikā.',
          solution: 'Tiešsaistes rezervāciju sistēma, kas automātiski pārvalda boksu kapacitāti.',
          benefits: ['Sezonas maiņas atgādinājumi', 'Riepu viesnīcas uzskaite', 'Tiešsaistes rezervāciju saites']
        },
        {
          id: 'glass',
          title: 'Auto Stiklu Maiņa',
          description: 'Paātriniet apdrošināšanas pieteikumus un uzstādīšanu.',
          problem: 'Komunikācijas kavēšanās ar klientiem, gaidot stiklus.',
          solution: 'Automatizēti statusa atjauninājumi, kad stikls ir klāt.',
          benefits: ['Noliktavas paziņojumi', 'Mobilā servisa plānošana', 'Apdrošināšanas dokumentu augšupielāde']
        },
        {
          id: 'towing',
          title: 'Evakuators / Auto Palīdzība',
          description: 'Dispečerējiet un informējiet klientus nekavējoties.',
          problem: 'Klienti satraucas par ierašanās laikiem.',
          solution: 'Automatizēti ETA (ierašanās laika) SMS un sekošanas saites.',
          benefits: ['GPS sekošanas saites', 'Atsauksmju pieprasījumi pēc servisa', 'Partneru servisu ieteikumi']
        },
        {
          id: 'parts',
          title: 'Auto Rezerves Daļas',
          description: 'Veiciniet atkārtotus pirkumus un pārvaldiet specpasūtījumus.',
          problem: 'Zaudēti pirkumi no pamestiem groziem vai aizmirstiem pieprasījumiem.',
          solution: 'Pamesto grozu atgūšana un noliktavas paziņojumu automatizācija.',
          benefits: ['Atjaunotā atlikuma brīdinājumi', 'Pamesto grozu SMS', 'Lojalitātes punktu sistēma']
        },
        {
          id: 'school',
          title: 'Autoskolas',
          description: 'Aizpildiet grupas un automatizējiet braukšanu plānošanu.',
          problem: 'Instruktoru un studentu grafiku manuāla koordinēšana.',
          solution: 'Pašapkalpošanās rezervāciju kalendārs braukšanas nodarbībām.',
          benefits: ['Nodarbību atgādinājumi', 'Tiesību atjaunošanas mārketings', 'Instruktoru pieejamības pārvaldība']
        }
      ]
    },
    why: {
      title: 'Kāpēc Izvēlēties MOKO?',
      subtitle: 'Mēs nedodam jums tikai programmatūru. Mēs dodam pilnībā uzbūvētu sistēmu, kas gatava audzēt jūsu biznesu.',
      features: [
        { id: '1', title: 'Viss Vienā', description: 'Aizstājiet 5+ dažādus rīkus. CRM, E-pasts, SMS, Rezervācijas un Mājaslapa vienuviet.', icon: Settings },
        { id: '2', title: 'Auto Specializācija', description: 'Mēs strādājam tikai ar auto uzņēmumiem. Mēs saprotam jūsu terminoloģiju un klienta dzīves ciklu.', icon: Target },
        { id: '3', title: 'Vienota Iesūtne', description: 'Facebook, Instagram, E-pasta un SMS ziņas nonāk vienā vienkāršā logā.', icon: MessageSquare },
        { id: '4', title: 'Datu Balstīts', description: 'Reāllaika paneļi, kas precīzi parāda, cik lielus ieņēmumus ģenerē jūsu mārketings.', icon: BarChart3 },
      ],
      trust: {
        secure: { title: 'Drošs & Uzticams', desc: 'Uzņēmuma līmeņa datu aizsardzība.' },
        experts: { title: 'Auto Specializācija', desc: 'Pielāgoti rīki jūsu nozarei.' },
        support: { title: 'Vietējais Atbalsts', desc: 'Mēs atrodamies Rīgā, Latvijā.' }
      }
    },
    automations: {
      titlePre: 'Beidziet Dzīties Pēc Klientiem.',
      titleHighlight: 'Sāciet Tos Noslēgt.',
      description: 'Iedomājieties sistēmu, kas sazinās ar katru interesentu 2 minūšu laikā, 24/7. MOKO nodrošina, ka neviena iespēja nepazūd.',
      cta: 'Apskatīt Visas Automatizācijas',
      items: [
        { title: 'Neatbildēta Zvana SMS', desc: 'Automātiski nosūtiet SMS klientiem, kuri zvana, kad esat aizņemts.', iconType: 'phone' },
        { title: 'Pieraksta Atgādinājumi', desc: 'Krasi samaziniet neierašanos ar automatizētiem apstiprinājumiem.', iconType: 'calendar' },
        { title: 'Google Atsauksmju Ģenerators', desc: 'Pārvērtiet laimīgus klientus par 5-zvaigžņu atsauksmēm automātiski.', iconType: 'star' }
      ],
      chat: {
        title: 'Demo: Neatbildēts Zvans',
        user1: 'Sveiki, vai šodien ir brīvs laiks mazgāšanai?',
        bot1: 'Sveiki! Paldies, ka sazinājāties ar MOKO Auto. Esam nedaudz aizņemti, bet varat rezervēt laiku šeit: moko.lv/rezervet',
        user2: 'Lieliski, tikko rezervēju uz 14:00.',
        bot2: 'Perfekti! Esam apstiprinājuši jūsu laiku šodien 14:00. Tiekamies!',
        powered: 'Nodrošina MOKO Automatizācija'
      }
    },
    testimonials: {
      title: 'Uzticas Uzņēmumu Īpašnieki',
      items: []
    },
    contact: {
      title: 'Gatavs Automatizēt?',
      description: 'Piesakiet bezmaksas konsultāciju, lai redzētu, kā MOKO var palīdzēt tieši jūsu biznesam ietaupīt laiku un nopelnīt vairāk.',
      labels: {
        email: 'Rakstiet Mums',
        call: 'Zvaniet Mums',
        office: 'Apciemojiet Mūs',
        name: 'Vārds Uzvārds',
        workEmail: 'Darba E-pasts',
        company: 'Uzņēmuma Nosaukums',
        businessType: 'Biznesa Veids',
        bookBtn: 'Pieteikt Konsultāciju',
        disclaimer: 'Nosūtot šo veidlapu, jūs piekrītat saņemt ziņojumus no MOKO.'
      },
      businessTypes: ['Auto Mazgātava', 'Auto Serviss', 'Detailing', 'Auto Noma', 'Auto Tirdzniecība', 'Cits']
    },
    footer: {
      rights: 'Visas tiesības aizsargātas.'
    }
  }
};

export const getContent = (lang: Language) => CONTENT[lang];
